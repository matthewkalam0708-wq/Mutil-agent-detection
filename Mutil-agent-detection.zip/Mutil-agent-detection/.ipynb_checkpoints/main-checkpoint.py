import yaml
from perception_agent import PerceptionAgent
from reasoning_agent import ReasoningAgent
from control_agent import ControlAgent

def main():
    with open("../config/config.yaml", "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    perception = PerceptionAgent(config)
    reasoning = ReasoningAgent(config)
    control = ControlAgent(config)

    print("==== 工业视觉质检多Agent系统启动 ====")
    while True:
        try:
            img, kpts = perception.run()
            status, traj = reasoning.run(kpts)
            print("检测状态：", status)
            if traj:
                ok = control.run(traj)
                print("机械手指令下发：", "成功" if ok else "失败")
        except KeyboardInterrupt:
            print("系统退出")
            break
        except Exception as e:
            print("运行异常：", e)

if __name__ == "__main__":
    main()