import cv2
import numpy as np
from ultralytics import YOLO

class PerceptionAgent:
    def __init__(self, config):
        self.config = config
        self.model = YOLO(config["model"]["path"])
        self.camera = cv2.VideoCapture(0)

    def capture_image(self):
        ret, frame = self.camera.read()
        if not ret:
            raise RuntimeError("相机采集失败")
        return frame

    def detect_keypoints(self, image):
        results = self.model(
            image,
            conf=self.config["model"]["conf_threshold"],
            iou=self.config["model"]["nms_threshold"]
        )
        if not results[0].keypoints:
            return None
        return results[0].keypoints.xy[0].cpu().numpy()

    def run(self):
        image = self.capture_image()
        keypoints = self.detect_keypoints(image)
        return image, keypoints