import socket

class ControlAgent:
    def __init__(self, config):
        self.config = config
        self.robot_ip = config["robot"]["ip"]
        self.robot_port = config["robot"]["port"]
        self.sock = None

    def connect_robot(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((self.robot_ip, self.robot_port))

    def send_command(self, cmd):
        if not cmd:
            return False
        self.sock.sendall(cmd.encode("utf-8"))
        resp = self.sock.recv(1024).decode("utf-8")
        return resp == "OK"

    def close(self):
        if self.sock:
            self.sock.close()

    def run(self, trajectory):
        try:
            self.connect_robot()
            res = self.send_command(trajectory)
        except Exception as e:
            print("机械手通信异常：", e)
            res = False
        self.close()
        return res