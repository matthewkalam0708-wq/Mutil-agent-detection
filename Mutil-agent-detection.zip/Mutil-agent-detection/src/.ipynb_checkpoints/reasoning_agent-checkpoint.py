import numpy as np

class ReasoningAgent:
    def __init__(self, config):
        self.config = config
        try:
            self.homography_matrix = np.load(config["calibration"]["homography_matrix_path"])
        except:
            self.homography_matrix = np.eye(3)

    def defect_inspection(self, keypoints):
        if keypoints is None:
            return "NO_OBJECT"
        distances = np.linalg.norm(keypoints[1:] - keypoints[:-1], axis=1)
        if np.any(distances < 5) or np.any(distances > 20):
            return "DEFECTIVE"
        return "PASS"

    def pixel_to_robot_coords(self, pixel_pts):
        pixel_h = np.hstack([pixel_pts, np.ones((len(pixel_pts), 1))])
        robot_pts = (self.homography_matrix @ pixel_h.T).T
        robot_pts = robot_pts[:, :2] / robot_pts[:, 2:]
        return robot_pts

    def plan_trajectory(self, robot_pts, defect_status):
        if defect_status == "PASS":
            target = [robot_pts[0,0], robot_pts[0,1], 50, 0, 0, 0]
        else:
            target = [robot_pts[0,0], robot_pts[0,1], 50, 90, 0, 0]
        return f"POSE,{target[0]},{target[1]},{target[2]},{target[3]},0,0,0,R"

    def run(self, keypoints):
        status = self.defect_inspection(keypoints)
        traj = None
        if keypoints is not None:
            robot_pts = self.pixel_to_robot_coords(keypoints)
            traj = self.plan_trajectory(robot_pts, status)
        return status, traj